gamma-readme
